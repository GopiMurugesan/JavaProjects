package com.cts.files;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

public class MergeFiles 
{
	//Source Files
	public static String baseFile = "D:\\GitCheckouts\\FileMerger\\src\\resources\\ITEM_SUN_SSKU_VSKU_20170327105221.MNT";
	public static String storeFile = "D:\\GitCheckouts\\FileMerger\\src\\resources\\ITEM_STORE_0916_20170328100514.MNT";
	//Output File
	public static String outputFile = "D:\\GitCheckouts\\FileMerger\\src\\resources\\ITEM_MASTER_SKU.MNT";
	//Header
	public static String header = "<<Header Information Passed as input to the program>>";	
	//Logger
	static Logger logger = Logger.getLogger(MergeFiles.class.getName());
	
	public static void main(String...args)
	  {
		//Call this method by passing header,basefile, storefile and output file as input arguments
		mergeFiles(header,baseFile,storeFile,outputFile);	
	  }

	private static void mergeFiles(String header,String baseFile, String storeFile, String outputFile)
	{
		List<Integer> baseSKUIDs = readBaseFile(baseFile);
		List<Integer> storeSKUIDs = readStoreFile(storeFile);	
		Set<Integer> masterSKUList = createMasterSKUList(baseSKUIDs,storeSKUIDs);
		createMasterSKUFile(masterSKUList,baseFile,storeFile,outputFile,header);
		logger.info("Output File is created successfully in the folder " + outputFile);
	}

	private static void createMasterSKUFile(Set<Integer> masterSKUIDs,String baseFile, String storeFile, String outputFile,String header) 
	{
		logger.info("Writing the Record from Store file Started....");
		try(CSVReader reader = new CSVReader(new FileReader(storeFile), '|', '\0', 1);
			CSVWriter writer = new CSVWriter(new FileWriter(outputFile), '|', '\0', "\n");)			
		{
			Set<Integer> recordsWrittenToFile = new HashSet<Integer>();
			
			String[] row;
			//Set the Header
			writer.writeNext(header.split("\n"));
		    while((row = reader.readNext()) != null) 
		    {
		    	for(int skuID : masterSKUIDs)
		    	{
		    		if(Integer.parseInt(row[2]) == skuID)	
		    		{
		    			recordsWrittenToFile.add(skuID);
		    			writer.writeNext(row);
		    		}
		    		else
		    		{
		    			continue;
		    		}
		    	}
		    }
		    logger.info("Writing the Record from Store file Completed....");
		     writeBaseFileRecords(recordsWrittenToFile,masterSKUIDs,writer,baseFile);
		}
		catch (FileNotFoundException e) 
		{
		    logger.severe("File Not found Exception Occured " + e.getMessage());
		}
		catch (IOException e) 
		{
			logger.severe(" IOException Occured " + e.getMessage());
		}			
	}

	private static void writeBaseFileRecords(Set<Integer> recordsWrittenToFile ,Set<Integer> masterSKUIDs, CSVWriter writer,String baseFile) 
	{
		logger.info("Writing the Record from Base file Started....");
		
		for(int id1 : recordsWrittenToFile)
		{
			//Remove already written records from the list
			if(masterSKUIDs.contains(id1))
			{
				masterSKUIDs.remove(id1);
			}
		}
		try(CSVReader reader = new CSVReader(new FileReader(baseFile), '|', '\0', 1);)
		{
			String[] row;    
		    while((row = reader.readNext()) != null) 
		    {
		    	for(int skuID : masterSKUIDs)
		    	{
		    		if(Integer.parseInt(row[2]) == skuID)	
		    		{
		    			writer.writeNext(row);
		    		}
		    		else
		    		{
		    			continue;
		    		}
		    	}
		    }
		}
		catch (FileNotFoundException e) 
		{
		    logger.severe("File Not found Exception Occured " + e.getMessage());
		}
		catch (IOException e) 
		{
			logger.severe(" IOException Occured " + e.getMessage());
		}
		logger.info("Writing the Record from Base file Completed....");
		
	}

	private static Set<Integer> createMasterSKUList(List<Integer> baseSKUIDs, List<Integer> storeSKUIDs) 
	{
		Set<Integer> masterSKUIDs = new HashSet<Integer>();
		masterSKUIDs.addAll(baseSKUIDs);
		masterSKUIDs.addAll(storeSKUIDs);
		logger.info("Total Number of Unique SKU's from Base and Store file --" + masterSKUIDs.size());
		return masterSKUIDs;	
	}

	private static List<Integer> readStoreFile(String storeFile) 
	{
		logger.info("Reading SKUID's from Store File - Started");
		List<Integer> storeSKUIDs = null;
		try(CSVReader reader = new CSVReader(new FileReader(storeFile), '|', '\0', 1);)
		 {   
		     String[] row;
		     storeSKUIDs = new  ArrayList<Integer>();
		    while((row = reader.readNext()) != null) 
		    {
		    	storeSKUIDs.add(Integer.parseInt(row[2]));
		    }
		}
		catch (FileNotFoundException e) 
		{
		    logger.severe("File Not found Exception Occured " + e.getMessage());
		}
		catch (IOException e) 
		{
			logger.severe(" IOException Occured " + e.getMessage());
		}
		logger.info("Reading SKUID's from Store File - Completed");
		return storeSKUIDs;
		
	}

	private static List<Integer> readBaseFile(String baseFile) 
	{
		logger.info("Reading SKUID's from Base File - Started");
		List<Integer> baseSKUIDs = null;
		try(CSVReader reader = new CSVReader(new FileReader(baseFile), '|', '\0', 1);)
		{ 
		     String[] row;
		     baseSKUIDs = new  ArrayList<Integer>();
		    
		    while((row = reader.readNext()) != null ) 
		    {
		    	baseSKUIDs.add(Integer.parseInt(row[2]));
		    }
		}
		catch (FileNotFoundException e) 
		{
			logger.severe("File Not found Exception Occured " + e.getMessage());
		}
		catch (IOException e) 
		{
			logger.severe(" IOException Occured " + e.getMessage());
		}
		logger.info("Reading SKUID's from Base File - Completed");
		return baseSKUIDs;
	}
}
